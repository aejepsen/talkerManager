module.exports = {
  rootDir: './tests',
  testSequencer: './assets/sequencer.js',
  testRegex: './*\\.test\\.js$',
  testTimeout: 180000,
};
